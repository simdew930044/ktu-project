// const server = http.createServer((req, res) => {
//     const url = req.url;
//     if (url === '/auth/login.php') {
//       // Return the login page
//       res.writeHead(200, {'Content-Type': 'text/html'});
//       res.end('<html><body><h1>Login Page</h1><form>...</form></body></html>');
//     } else {
//       // Return a 404 error for unknown URLs
//       res.writeHead(404, {'Content-Type': 'text/plain'});
//       res.end('Not Found');
//     }
//   });

// Main
        // Combine window.onload events
        // window.onload = () => {
          // Search input functionality
          const searchInputCtn = document.querySelector('.search-input-ctn');
          const closeWindowModal = document.querySelector('.close-window-modal');
          let topNavItems=document.querySelector(".top-nav > ul ").innerHTML;
          // Welcome message animation
          const welcomeMessage = "WELCOME TO THE NEW AND TOP BRANDED GROCCERY ONLINE STORE";
          const welcomeMessageArray = welcomeMessage.split(" ");
          const welcomeMessageContainer = document.querySelectorAll('.page-header');
          let i = 0;
          const welcomeMessageLength = welcomeMessage.length;

          document.querySelector(".side-nav > ul").innerHTML=topNavItems
          const openSearch = document.querySelectorAll('.open-search');
        
          // Slide show functionality
         // Slide show functionality
        const welcomeImg = document.querySelectorAll(".welcome-img > .item");
        const totalSlides = welcomeImg.length;
        let currentSlideIndex = 0;
        
        function showSlide(n) {
          welcomeImg.forEach((slide) => {
            slide.classList.add("hidden-slide");
          });
          welcomeImg[n].classList.remove("hidden-slide");
        }
        
        function nextSlide() {
          currentSlideIndex = (currentSlideIndex + 1) % totalSlides;
          showSlide(currentSlideIndex);
        }
        
        setInterval(nextSlide, 10000); // change slide every 3 seconds
        
        // Initialize the slideshow
        

                                            // Get all products
        const products = document.querySelectorAll('.product');
        products.forEach((product)=>{
                btn="<button class='add'>+ add</button>";
                product.innerHTML+=(btn);
        })
        
        // Function to check if element is in viewport
        function isInViewport(element) {
            const rect = element.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        }
            
         // Add event listener to window scroll
         window.addEventListener('scroll', () => {
          products.forEach((product) => {
              if (isInViewport(product)) {
                  product.classList.add('in-view');
              } else {
                  product.classList.remove('in-view');
              }
          });
      });
      
      productsImages=document.querySelectorAll(".product > img")
      // for (i =0; i < productsImages.length; i++){
      //     currentProduct=productsImages[i];
      //     imgSrc=`images/img${i}.jpg`;
      //     currentProduct.setAttribute("src", imgSrc)
      
      // }
      document.querySelectorAll(".add").forEach((add)=>{
          spinner="<div class='spinner-sm'></div>";
          add.onclick=()=>{
              purchased=add.innerHTML;
              if(purchased != "purchased"){
                  setTimeout(() => {
                      add.innerHTML=spinner;
                  setTimeout(() => {
                      add.innerHTML="purchased";
                  }, 1000);
              }, 0);
              }else{
                alert("Item already purchased");
              }
              
              
          }
          
      })
      
      
      // Navogation
      document.querySelector(".open-side-nav").onclick=()=>{
          document.querySelector(".side-nav").classList.add("active-side-nav");
      }
      document.querySelector(".close-side-nav").onclick=()=>{
          document.querySelector(".side-nav").classList.remove("active-side-nav");
      }
      openSearch.forEach((element) => {
        element.addEventListener("click", ()=>{
            searchInputCtn.classList.remove('hidden');
        })
      })
    
      closeWindowModal.onclick = () => {
        searchInputCtn.classList.add('hidden');
      };

      
    // }
      function writeTextContent(elementClass, textSource, interval){
        textcounter=0;
        elementClass=document.querySelectorAll("."+elementClass);
        lenthOfText=textSource.length
        function writeText() {
        if (textcounter < lenthOfText) {
          const nextText = textSource.charAt(textcounter);
          elementClass.forEach((element)=>{
            element.innerHTML += nextText;
          })
          
          textcounter++;
          setTimeout(writeText, interval);
        }
      }
      writeText()
      }
        
       

      // INsertin footer and navbar element
      let footerContent=`<div class='main-footer'>
      <div class='footer-group'>
          <div class='header'>About us</div>
          <ul>
              <p>Editec stores provide all grocery needs for the enitre family.
                  <br>
                  We are very interested in serving our customers with good and quality products.
              </p>
          </ul>
      </div>
      <div class='footer-group'>
          <div class='header'>Top Purchases</div>
          <ul>
              <li><a href=''>Milk powder</a></li>
              <li><a href=''>Cheese</a></li>
              <li><a href=''>Soya beans</a></li>
              <li><a href=''>Others</a></li>
          </ul>
      </div>
      <div class='footer-group'>
          <div class='header'>Contact</div>
          <ul>
              <li>Location:KSTu, Amakom, Kumasi, Ashanti Region Ghana</li>
              <li>Phone: +233553739773</li>
              <li>Whatsapp: +233249711380</li>
          </ul>
      </div>
  </div>
  <div class='copyright'>
      
      <div>All right reserved </div>
      <span class='copyright-symbol'>&copy;</s>
          <div>Contributed by the KSTU . Team</div>
          <br>2024
  </div>`;

  document.querySelector("footer").innerHTML=footerContent;

  // window.onload=()=>{
    let mainBodyContent=document.querySelector(".body-content");
    let pageLoaderContainer=document.querySelector(".page-loader-container");

    setTimeout(() => {
      pageLoaderContainer.classList.add("hidden");
      mainBodyContent.classList.remove("hidden");
    }, 1000);
  // }